import React from "react";

// {children ? renderElAlert() : message}

export default function ConfirmedBooking() {
  return <div>HALLO</div>
}
