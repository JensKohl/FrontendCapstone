import React from "react";
import "../index.css";

export default function About() {
  return <div>Little Lemon is a ....</div>;
}
