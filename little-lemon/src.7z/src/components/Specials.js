import React from "react";
import "../index.css";
import Bruschetta from '../images/bruschetta.jpg';
import GreekSalad from '../images/greek salad.jpg';
import LemonDessert from '../images/lemon dessert.jpg';

export default function Specials (){
    return (
        <div>
            <section>
                <article>
                    <h2>Greek Salad</h2>
                    <img src={GreekSalad} alt="Greek Salad" width={250} height={250}/>
                    The famous greek salad
                </article>
                <article>
                    <h2>Bruschetta</h2>
                    <img src={Bruschetta} alt="Bruschetta" width={250} height={250}/>
                    Our Bruschetta is made from....
                </article>
                <article>
                    <h2>Lemon dessert</h2>
                    <img src={LemonDessert} alt="Lemon Dessert" width={250} height={250}/>
                    This comes straight
                </article>
            </section>
        </div>
    );
}