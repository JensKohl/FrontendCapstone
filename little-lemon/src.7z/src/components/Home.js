import Main from './Main.js';

function Home() {
  return (
    <>
    <Main/>
    </>
  );
}

export default Home;