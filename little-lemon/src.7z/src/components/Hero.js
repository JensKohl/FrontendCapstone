import { React, useState } from "react";
import { BookingState } from "./../App";
import "../index.css";
import BookingForm from "./BookingPage";

import RestaurantPic from '../images/restauranfood.jpg';
import Specials from "./Specials";

export function HeroForm(props) {
  console.log(props.BookingState);
  return (
    <div>
      <main className="grid-container">
        <div className="Main">
          <h1>Little Lemon</h1>
          <h2>Chicago</h2>
          <p>
            We are a family owned Mediterranean restaurant, focused on
            traditional recipes served with a modern twist.
          </p>
          
        <div className="Herocontainer">
        <p>We are a family owned Mediterranean restaurant, focused on traditional recipes served with a modern twist.</p>
        <img src={RestaurantPic} alt="logo" width={250} height={250}/>
        </div>
                <button aria-label="reserve" onClick={props.toggleBool}>Reserve a table</button>
        </div>

        <Specials className="Specials"/>
      </main>
    </div>
  );
}

export const Hero = (props) => {
  const [myBool, setmyBool] = useState(true);

  function toggleBool() {
    setmyBool(!myBool);
  }

  return myBool ? (
    <HeroForm toggleBool={toggleBool} BookingState={BookingState} />
  ) : (
    <BookingForm BookingState={BookingState} />
  );
};

export default Hero;
