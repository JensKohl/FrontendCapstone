import '../index.css'
import React, { useReducer } from "react";
import { reducer, initialState, BookingState } from "./../App";
import { fetchAPI, submitAPI } from './../ExternAPI';

const BookingForm = (props) => {
  const [BookingState, dispatcher] = useReducer(reducer, initialState);

  //let navigate = useNavigate();

  const dateChanger = (e, BookingState) => {
    dispatcher({ type: "DATE", payload: e.target.value });
    initialState.availableTimes = fetchAPI(new Date(e.target.value));
    console.log(fetchAPI(new Date(e.target.value)));

  };

  const timeChanger = (e) => {
    dispatcher({ type: "TIME", payload: e.target.value });
  };

  const GuestChanger = (e) => {
    dispatcher({ type: "GUESTS", payload: e.target.value });
  };

  const OccasionChanger = (e) => {
    dispatcher({ type: "OCCASION", payload: e.target.value });
  };

  const SubmitHandler = (e) => {
    /*alert/("WHEN: " + BookingState.date + " AT: " + BookingState.time + " HOW MANY: " + BookingState.guests + " WHY: " + BookingState.occasion);*/
    console.log("WHEN: " + BookingState.date + " AT: " + BookingState.time + " HOW MANY: " + BookingState.guests + " WHY: " + BookingState.occasion);

    const formData = new FormData();

    if (submitAPI(formData)){
      alert("Booking on " + BookingState.date + 
            " at " + BookingState.time + 
            " for " + BookingState.guests + 
            " guests for occassion " + BookingState.occasion + 
            " was successful!")
      //navigate(`/ConfirmedBooking`);
    }
    else{
      console.log("FEHLER!");
    }
  };

  const enabledButton = BookingState.date !== "" &&
                        BookingState.time !== "" && typeof(BookingState.time) !== "undefined" &&
                        BookingState.guests > 1  &&
                        BookingState.occasion !=="" && typeof(BookingState.time) !== "undefined";


  return (
    <div className="SubmitForm">
     <h1>Book a table</h1>

        <div className="DateSelect">
          Choose a date: 
          <input type="date"
                 id="res-date"
                 name="DateSelectInput"
                 min="2023-01-01"
                 onChange={dateChanger} />
        </div>

        <p/>

        Choose a time:
        <select required onChange={timeChanger}>
        {initialState.availableTimes.map((x) => (
          <option key={x}>{x}</option>
        ))}
        </select>

        <p/>

        Number of guests:
        <input  type="number"
                id="guest-number-select"
                min="1" max="5"
                onChange={GuestChanger}
                defaultValue="1"/>
        <p/>

        Occasion
        <select required name="SelectTime" id="time-select" onChange={OccasionChanger}>
        {initialState.occasion.map((x) => (
          <option key={x}>{x}</option>
        ))}
      </select>

        <p/>
        <button aria-label="send" disabled={!enabledButton} onClick={SubmitHandler}>SUBMIT</button>
      </div>
    );
  }

  export default BookingForm;