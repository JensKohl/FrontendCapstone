import React from "react";
import '../index.css'

const Footer = () => {
  return (
    <footer className='footer'>
      (c) Little Lemon 2022
    </footer>
  );
};

export default Footer;

