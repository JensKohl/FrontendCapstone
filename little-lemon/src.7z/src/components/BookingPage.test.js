import { render, screen, fireEvent } from "@testing-library/react";
import BookingForm from './BookingPage';


describe("First Test", () => {
test('Renders the BookingForm heading', () => {
    render(<BookingForm />);
    const headingElement = screen.getByText("Book a table");
    expect(headingElement).toBeInTheDocument();
});
});