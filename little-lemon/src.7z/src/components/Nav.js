import React from "react";
import "../index.css";
import { Link } from "react-router-dom";

function Nav() {
    return (
      <nav className='Nav'>
        <div>
        <Link to="/home">Home</Link>
        <Link to="/about">About</Link>
        <Link to="/">Menu</Link>
        <Link to="/BookingForm">Reservation</Link>
        <Link to="/">Order Online</Link>
        <Link to="/">Login</Link>
        </div>
      </nav>
    )
  }


export default Nav